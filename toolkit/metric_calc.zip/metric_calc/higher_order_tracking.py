

class CalcHigherOrderTracking:
    

    def calc_object_association_score():
        return None
    
    def calc_object_detection_score():
        return None
    
    def calc_object_detection_accuracy():
        return None
    
    def calc_higher_order_accuracy_score():
        return