

class CalcStandard: 