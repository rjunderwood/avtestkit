

class CalcMotionPlanning: 
    

    def calc_object_time_to_collision():
        return None
    
    def calc_object_exposed_time_to_collision():
        return None
    
    def calc_object_post_encroachment_time():
        return None

    def calc_total_near_collisions():
        return None
    
    def calc_safe_logitudinal_distance():
        return None
    
    def calc_safe_lateral_distance():
        return None

    def calc_total_longitudinal_distance_violations():
        return None
    
    def calc_total_lateral_distance_violations():
        return None
    
    
