


class CalcEnvironmentPerception:
    
    def calc_estimate_object_class():
        return None

    def calc_estimated_object_velocity():
        return None

    def calc_estimated_object_position():
        return None

    def calc_estimated_object_velocity_variance():
        return None

    def calc_estimated_object_position_variance():
        return None
        
    def calc_object_recall_positivity():
        return None
    
    def calc_object_recall_positivity():
        return None

    def calc_object_recall_sensitivity():
        return None
    
    def calc_object_precision_confidence():
        return None
    
    def calc_object_harmonic_mean():
        return None
    
    def calc_object_jaccard_distance():
        return None
    
    def calc_object_intersection_over_union():
        return None
    
    def calc_object_mota():
        return None
    
    def calc_object_motp():
        return None

    def ego_lane_offset():
        return None

    def ego_lane_offset_variance():
        return None